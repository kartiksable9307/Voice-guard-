# 🛡️ VOICEGUARD: AI Voice Impersonation & Deepfake Audio Detection System

**VoiceGuard** is an end-to-end AI cybersecurity application designed to detect AI-synthesized, text-to-speech (TTS), and cloned voice impersonation attacks in real-time. It analyzes the biometric and acoustic properties of human vocal tract dynamics versus neural vocoder artifacts to protect organizations and individuals against voice spoofing and deepfake social engineering.

---

## 📋 Table of Contents
1. [Project Overview & Problem Statement](#-project-overview--problem-statement)
2. [Key Features & Modules](#-key-features--modules)
3. [System Architecture](#-system-architecture)
4. [Acoustic Biometric Detection Engine](#-acoustic-biometric-detection-engine)
5. [Tech Stack](#-tech-stack)
6. [Project Structure](#-project-structure)
7. [Installation & Setup Guide](#-installation--setup-guide)
8. [API Documentation](#-api-documentation)
9. [College Presentation & Viva Q&A Guide](#-college-presentation--viva-qa-guide)

---

## 🎯 Project Overview & Problem Statement

### The Threat:
With the rapid evolution of generative AI tools (such as ElevenLabs, VITS, HiFi-GAN, and Tacotron), malicious actors can clone a human voice using just a few seconds of sample audio. This has led to high-profile attacks:
- **CEO Fraud & Financial Scams**: Impersonating executives over phone calls to authorize emergency fund transfers.
- **Biometric Bypass**: Circumventing automated voice authentication systems used by financial institutions.
- **Family Emergency Scams**: Cloning family members' voices to fabricate urgent distress scenarios.

### The Solution:
**VoiceGuard** intercepts audio streams (via live microphone recording or file upload) and runs deep mathematical decomposition on the frequency spectrum to detect unnatural vocoder smoothing, lack of physiological formant dynamics, and digital silence gating, delivering immediate risk assessments.

---

## ✨ Key Features & Modules

### 🎙️ Module 1: Live Voice Recording Component
- Uses the **Web Audio API** (`AudioContext` and script processor) to capture raw microphone PCM samples directly at 22,050 Hz.
- Encodes samples directly into **16-bit uncompressed WAV** format in-browser, preventing compression loss and ensuring universal platform compatibility.
- Visual state machine: `Idle` ➔ `Recording...` (with real-time animated waveform bars & timer) ➔ `Audio Recorded` (with preview player & reset).

### 📁 Module 2: Universal Audio File Upload
- Drag-and-drop zone and file picker supporting `.wav`, `.mp3`, `.ogg`, `.m4a`, and `.webm`.
- Integrates an in-browser audio player preview to listen to the uploaded file before running analysis.

### 🔬 Module 3: Deep Feature Extraction & Analysis Trigger
- Sends multi-part audio streams to the FastAPI backend.
- Background **FFmpeg + Librosa** pipeline ensures decoding of any audio container or sample rate.

### 📊 Module 4: Live Results & Biometrics Dashboard
- **Dual Percentage Meters**: High-contrast animated progress bars for **AI Synthetic %** vs **Authentic Human %**.
- **Dynamic Risk Badge**:
  - 🟢 **LOW RISK** (< 35% AI): Authentic Human Voice Verified.
  - 🟡 **MEDIUM RISK** (35% – 69% AI): Suspicious Audio Characteristics.
  - 🔴 **HIGH RISK** (≥ 70% AI): Possible Voice Impersonation Detected.
- **Biometric Feature Matrix**: Displays extracted mathematical metrics:
  - *MFCC Variance (Cepstral dynamic spread)*
  - *Spectral Flatness (Whiteness / noisiness coefficient)*
  - *Zero-Crossing Rate (High-frequency transitions)*
  - *Spectral Rolloff (Energy distribution cutoff frequency)*

### ⚠️ Module 5: Conditional Fraud Prevention Protocol
- When **HIGH RISK** is triggered, a pulsing critical alert box displays immediate defense actions:
  - ⛔ *Halt financial / wire authorizations.*
  - 📞 *Initiate out-of-band video or visual verification.*
  - 📝 *Log biometric incident report.*

---

## 🏗️ System Architecture

```
┌────────────────────────────────────────────────────────┐
│                   FRONTEND UI LAYER                   │
│   (React / Modern Tailwind CSS Dark Dashboard)         │
│                                                        │
│  [ Mic Recording (WAV) ]   OR   [ File Upload (.mp3) ] │
└──────────────────────────┬─────────────────────────────┘
                           │ HTTP POST /api/analyze
                           ▼
┌────────────────────────────────────────────────────────┐
│                 BACKEND SERVICE LAYER                  │
│                     (FastAPI Server)                   │
├────────────────────────────────────────────────────────┤
│  1. Ingest & FFmpeg Format Normalization               │
│  2. Librosa Acoustic Biometric Extraction:             │
│     • 20 Mel-Frequency Cepstral Coefficients (MFCCs)   │
│     • Temporal Delta-MFCCs & Formant Dynamics          │
│     • Spectral Flatness & Spectral Centroid Variance   │
│     • Zero Crossing Rate & RMS Energy Dynamics         │
│  3. Biometric Classification Algorithm                 │
│  4. JSON Response (Percentages, Risk Level, Telemetry) │
└──────────────────────────┬─────────────────────────────┘
                           │ Returns JSON
                           ▼
┌────────────────────────────────────────────────────────┐
│               PRESENTATION DASHBOARD                   │
│  [ Human vs AI Meters ]  [ Risk Badge ]  [ Alert Box ] │
└────────────────────────────────────────────────────────┘
```

---

## 🧠 Acoustic Biometric Detection Engine

### How VoiceGuard Differentiates Human Voice from AI Voice:

| Acoustic Feature | Natural Human Voice | AI-Generated / Cloned Voice |
| :--- | :--- | :--- |
| **Formant Dynamics (MFCC 1–8)** | **High dynamic range** (> 60) due to pharynx, tongue, and lips moving during speech phonemes. | **Overly uniform** trajectory; neural models struggle with micro-articulatory transitions. |
| **High Cepstral Band Spread (MFCC 10–19)** | **High natural jitter** caused by vocal fold irregularities and room acoustics. | **Smooth / Over-regularized** vocoder output without organic vocal micro-imperfections. |
| **Spectral Flatness Variation** | **High contrast** between resonant vowels (harmonic) and unvoiced consonants (fricatives). | **Atypical uniformity** across frequency frames caused by spectrogram inversion algorithms. |
| **Spectral Centroid Std Dev** | **High variability** (> 200 Hz std dev) across spoken words. | **Narrow frequency shift** within standard synthesis frequency envelopes. |
| **RMS Energy & Silence Gating** | **Continuous room acoustic floor** with natural breathing pauses. | **Digital silence** or sharp cutoffs between phoneme chunks. |

---

## 💻 Tech Stack

### Backend:
- **Python 3.10+ / 3.13**
- **FastAPI**: Asynchronous, high-performance API framework.
- **Uvicorn**: Lightning-fast ASGI production server.
- **Librosa (0.10.1)**: Music and audio analysis library for feature extraction.
- **SoundFile & SciPy**: Digital signal processing and PCM manipulation.
- **imageio-ffmpeg**: Embedded FFmpeg binary for universal audio format conversion.

### Frontend:
- **HTML5 / JavaScript / React**: Component-driven UI.
- **Tailwind CSS (Dark Theme)**: Modern glassmorphism, responsive grid layout, and custom animations.
- **Lucide Icons**: Crisp SVG security and telemetry icons.
- **Web Audio API**: Browser-native real-time PCM audio capture.

---

## 📁 Project Structure

```
voiceguard-mvp/
├── README.md                 # Complete documentation & viva presentation guide
├── backend/
│   ├── main.py               # FastAPI backend, Librosa analysis & embedded dashboard
│   └── requirements.txt      # Python dependencies
└── frontend/
    ├── index.html            # HTML shell
    ├── package.json          # Node dependencies & Vite build scripts
    ├── postcss.config.js     # PostCSS Tailwind configuration
    ├── tailwind.config.js    # Tailwind styling tokens & custom animations
    ├── vite.config.js        # Vite dev server configuration
    └── src/
        ├── App.jsx           # Full React application & dashboard component
        ├── index.css         # Global styles & Tailwind directives
        └── main.jsx          # React entry point
```

---

## 🚀 Installation & Setup Guide

### Method 1: Instant Single-Command Launch (Zero Node.js Required)

The backend includes the fully interactive, responsive dark dashboard directly:

```bash
# 1. Navigate to backend directory
cd backend

# 2. Install dependencies
python -m pip install -r requirements.txt

# 3. Start the VoiceGuard server
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```
Open your browser at: **[http://localhost:8000](http://localhost:8000)**

---

### Method 2: Running with React + Vite Development Server

If you have Node.js installed and want to run the React Vite frontend separately:

```bash
# Terminal 1: Backend
cd backend
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload

# Terminal 2: Frontend
cd frontend
npm install
npm run dev
```
Open your browser at: **[http://localhost:5173](http://localhost:5173)**

---

## 📡 API Documentation

### `POST /api/analyze`
Accepts an audio file and returns forensic acoustic classification data.

- **Request Type**: `multipart/form-data`
- **Form Data Field**: `file` (Audio file: `.wav`, `.mp3`, `.ogg`, `.webm`, `.m4a`)

#### Sample Response (`200 OK`):
```json
{
  "success": true,
  "human_percentage": 8.5,
  "ai_percentage": 91.5,
  "risk_level": "HIGH",
  "status": "Possible Voice Impersonation Detected",
  "warning_message": "⚠️ WARNING: Possible AI-generated voice detected. Do not trust sensitive requests. Verify the speaker through another channel.",
  "audio_duration_seconds": 3.42,
  "spectral_flatness_mean": 0.007841,
  "mfcc_variance_mean": 142.38,
  "zero_crossing_rate_mean": 0.0384,
  "spectral_rolloff_mean": 3840.50
}
```

### `GET /api/health`
Health check endpoint.
```json
{
  "status": "healthy",
  "engine": "FastAPI + Librosa + FFmpeg"
}
```

Interactive Swagger UI docs are accessible at: **`http://localhost:8000/docs`**

---

## 🎓 College Presentation & Viva Q&A Guide

### Q1: What is the core innovation behind VoiceGuard?
> **Answer**: VoiceGuard analyzes **biological vocal tract dynamics versus synthetic vocoder artifacts**. When humans speak, moving vocal articulators create dynamic formant shifts (MFCC 1–8) and natural micro-jitter. In contrast, neural text-to-speech vocoders exhibit flat high-frequency cepstral bands, unnatural spectral flatness, and digital silence gating.

### Q2: Why use MFCCs (Mel-Frequency Cepstral Coefficients)?
> **Answer**: The Mel scale approximates the human ear's non-linear frequency perception. MFCCs capture the acoustic power spectrum envelope, reflecting physical vocal tract shapes. Lower coefficients represent formant resonance; higher coefficients capture micro-jitter and harmonic excitation.

### Q3: How is latency minimized for real-time applications?
> **Answer**: Feature extraction is computed in under **350ms** using optimized vectorized NumPy and Librosa algorithms without requiring multi-gigabyte GPU models, making it lightweight for telecom and real-time streaming pipelines.

### Q4: How does VoiceGuard handle different audio recording formats?
> **Answer**: The system captures raw uncompressed 16-bit PCM WAV in the browser using the Web Audio API and features an automated backend **FFmpeg normalization pipeline** to decode MP3, WebM, OGG, and WAV without format mismatches.
