import React, { useState, useRef, useEffect } from 'react';
import {
  Shield,
  ShieldAlert,
  ShieldCheck,
  Mic,
  Square,
  UploadCloud,
  FileAudio,
  Play,
  Pause,
  RotateCcw,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  Waves,
  Sparkles,
  Zap,
  Info
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('record');

  // Audio Recording State
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [audioBlob, setAudioBlob] = useState(null);
  const [audioUrl, setAudioUrl] = useState(null);
  const [recordedFileName, setRecordedFileName] = useState('');

  // Upload State
  const [uploadedFile, setUploadedFile] = useState(null);
  const [uploadPreviewUrl, setUploadPreviewUrl] = useState(null);
  const [isDragging, setIsDragging] = useState(false);

  // Audio Playback
  const [isPlaying, setIsPlaying] = useState(false);
  const audioPlayerRef = useRef(null);

  // Analysis & Results State
  const [isLoading, setIsLoading] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);

  // MediaRecorder References
  const mediaRecorderRef = useRef(null);
  const mediaStreamRef = useRef(null);
  const audioChunksRef = useRef([]);
  const timerIntervalRef = useRef(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    return () => {
      if (audioUrl) URL.revokeObjectURL(audioUrl);
      if (uploadPreviewUrl) URL.revokeObjectURL(uploadPreviewUrl);
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [audioUrl, uploadPreviewUrl]);

  // --- MODULE 1: RECORD VOICE (Standard MediaRecorder) ---
  const startRecording = async () => {
    setErrorMessage(null);
    setAnalysisResult(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      mediaStreamRef.current = stream;

      let options = {};
      if (typeof MediaRecorder !== 'undefined') {
        if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          options = { mimeType: 'audio/webm;codecs=opus' };
        } else if (MediaRecorder.isTypeSupported('audio/webm')) {
          options = { mimeType: 'audio/webm' };
        } else if (MediaRecorder.isTypeSupported('audio/ogg;codecs=opus')) {
          options = { mimeType: 'audio/ogg;codecs=opus' };
        } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
          options = { mimeType: 'audio/mp4' };
        }
      }

      const recorder = new MediaRecorder(stream, options);
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const mimeType = recorder.mimeType || 'audio/webm';
        const ext = mimeType.includes('ogg')
          ? 'ogg'
          : mimeType.includes('mp4')
          ? 'm4a'
          : mimeType.includes('wav')
          ? 'wav'
          : 'webm';
        const blob = new Blob(audioChunksRef.current, { type: mimeType });
        const url = URL.createObjectURL(blob);
        setAudioBlob(blob);
        setAudioUrl(url);
        setRecordedFileName(`live_capture_${Date.now()}.${ext}`);
      };

      recorder.start(100);
      setIsRecording(true);
      setRecordingDuration(0);

      timerIntervalRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      console.error('Microphone Access Error:', err);
      setErrorMessage('Microphone access denied or unavailable: ' + err.message);
    }
  };

  const stopRecording = () => {
    if (isRecording) {
      setIsRecording(false);
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);

      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      }
    }
  };

  const clearRecording = () => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setAudioBlob(null);
    setAudioUrl(null);
    setRecordedFileName('');
    setRecordingDuration(0);
    setAnalysisResult(null);
    setIsPlaying(false);
  };

  // --- MODULE 2: FILE UPLOAD ---
  const handleFileChange = (file) => {
    if (!file) return;
    const validExtensions = ['.wav', '.mp3', '.ogg', '.m4a', '.webm', '.flac'];
    const hasValidExt = validExtensions.some((ext) => file.name.toLowerCase().endsWith(ext));
    const isAudioType = file.type.startsWith('audio/') || hasValidExt;

    if (!isAudioType) {
      setErrorMessage('Invalid file format. Please upload a .wav, .mp3, .ogg, or .webm audio file.');
      return;
    }

    setErrorMessage(null);
    setAnalysisResult(null);
    if (uploadPreviewUrl) URL.revokeObjectURL(uploadPreviewUrl);

    const url = URL.createObjectURL(file);
    setUploadedFile(file);
    setUploadPreviewUrl(url);
    setIsPlaying(false);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileChange(e.dataTransfer.files[0]);
    }
  };

  const clearUpload = () => {
    if (uploadPreviewUrl) URL.revokeObjectURL(uploadPreviewUrl);
    setUploadedFile(null);
    setUploadPreviewUrl(null);
    setAnalysisResult(null);
    setIsPlaying(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Audio Playback
  const togglePlayAudio = (url) => {
    if (!audioPlayerRef.current) return;
    if (isPlaying) {
      audioPlayerRef.current.pause();
      setIsPlaying(false);
    } else {
      audioPlayerRef.current.src = url;
      audioPlayerRef.current.play();
      setIsPlaying(true);
      audioPlayerRef.current.onended = () => setIsPlaying(false);
    }
  };

  // --- MODULE 3: API TRIGGER (Analyze Voice) ---
  const handleAnalyze = async () => {
    setErrorMessage(null);
    setIsLoading(true);

    const targetBlob = activeTab === 'record' ? audioBlob : uploadedFile;
    const targetName = activeTab === 'record' ? recordedFileName : uploadedFile?.name;

    if (!targetBlob) {
      setErrorMessage('Please record or upload an audio sample first.');
      setIsLoading(false);
      return;
    }

    try {
      const formData = new FormData();
      formData.append('file', targetBlob, targetName || 'audio_sample.wav');

      const apiUrl = 'http://localhost:8000/api/analyze';
      const response = await fetch(apiUrl, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.detail || `Server error: ${response.status}`);
      }

      const data = await response.json();
      setAnalysisResult(data);
    } catch (err) {
      console.error('Analysis failed:', err);
      setErrorMessage(err.message || 'Failed to connect to backend at http://localhost:8000.');
    } finally {
      setIsLoading(false);
    }
  };

  const formatTime = (secs) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  const hasAudioSource = activeTab === 'record' ? !!audioBlob : !!uploadedFile;
  const currentAudioUrl = activeTab === 'record' ? audioUrl : uploadPreviewUrl;

  return (
    <div className="min-h-screen bg-[#080C14] text-slate-100 flex flex-col selection:bg-blue-600 selection:text-white">
      <audio ref={audioPlayerRef} onEnded={() => setIsPlaying(false)} className="hidden" />

      {/* HEADER */}
      <header className="border-b border-slate-800/80 bg-[#0B0F19]/90 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 shadow-lg shadow-blue-500/20 ring-1 ring-blue-400/30">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
                  VOICEGUARD
                </h1>
                <span className="px-2 py-0.5 text-xs font-semibold uppercase tracking-wider bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-full">
                  Live Engine
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium">
                AI Voice Impersonation & Deepfake Detection System
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-full">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Acoustic Biometrics Active</span>
          </div>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full space-y-8">
        
        {/* Architecture Badges */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-[#111827]/80 backdrop-blur border border-slate-800/80 rounded-2xl p-4 flex items-center gap-3.5">
            <div className="p-3 bg-blue-500/10 rounded-xl border border-blue-500/20 text-blue-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Processing Engine</p>
              <p className="text-sm font-bold text-slate-100">FastAPI + Librosa + FFmpeg</p>
            </div>
          </div>

          <div className="bg-[#111827]/80 backdrop-blur border border-slate-800/80 rounded-2xl p-4 flex items-center gap-3.5">
            <div className="p-3 bg-indigo-500/10 rounded-xl border border-indigo-500/20 text-indigo-400">
              <Waves className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Biometric Verification</p>
              <p className="text-sm font-bold text-slate-100">20-MFCCs & Pitch Micro-Jitter</p>
            </div>
          </div>

          <div className="bg-[#111827]/80 backdrop-blur border border-slate-800/80 rounded-2xl p-4 flex items-center gap-3.5">
            <div className="p-3 bg-emerald-500/10 rounded-xl border border-emerald-500/20 text-emerald-400">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Detection Latency</p>
              <p className="text-sm font-bold text-emerald-400">&lt; 350ms Real-Time</p>
            </div>
          </div>
        </div>

        {/* CONDITIONAL HIGH-RISK WARNING BOX */}
        {analysisResult && analysisResult.risk_level === 'HIGH' && (
          <div className="relative overflow-hidden rounded-2xl border-2 border-red-500/80 bg-gradient-to-r from-red-950/80 via-red-900/50 to-red-950/80 p-6 shadow-2xl shadow-red-900/40">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-red-600 text-white rounded-xl shadow-lg ring-4 ring-red-500/20 animate-bounce">
                  <AlertTriangle className="w-7 h-7" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-black uppercase tracking-widest bg-red-600 text-white">
                      CRITICAL ALERT
                    </span>
                    <h3 className="text-lg font-extrabold text-red-100">
                      AI Voice Impersonation Detected
                    </h3>
                  </div>
                  <p className="mt-1 text-sm font-medium text-red-200/90">
                    ⚠️ WARNING: Possible AI-generated voice detected. Do not trust sensitive requests. Verify the speaker through another channel.
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2 text-xs font-semibold text-red-300">
                    <span className="bg-red-950/90 px-2.5 py-1 rounded-md border border-red-800/60">
                      • Stop Wire/Financial Approvals
                    </span>
                    <span className="bg-red-950/90 px-2.5 py-1 rounded-md border border-red-800/60">
                      • Trigger Out-of-Band Video Verification
                    </span>
                    <span className="bg-red-950/90 px-2.5 py-1 rounded-md border border-red-800/60">
                      • Log Security Incident
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {errorMessage && (
          <div className="rounded-xl border border-red-500/40 bg-red-950/40 p-4 text-red-300 text-sm flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-xs bg-red-900/60 hover:bg-red-800 px-2.5 py-1 rounded text-red-200"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* WORKFLOW GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* LEFT: AUDIO CAPTURE & ANALYZE */}
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-[#111827] border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
              
              <div className="flex border-b border-slate-800 bg-[#0D131F]">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('record');
                    setIsPlaying(false);
                  }}
                  className={`flex-1 py-3.5 px-4 font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
                    activeTab === 'record'
                      ? 'bg-[#111827] text-blue-400 border-b-2 border-blue-500'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Mic className="w-4 h-4" />
                  Record Voice (Live)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('upload');
                    setIsPlaying(false);
                  }}
                  className={`flex-1 py-3.5 px-4 font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
                    activeTab === 'upload'
                      ? 'bg-[#111827] text-blue-400 border-b-2 border-blue-500'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <UploadCloud className="w-4 h-4" />
                  Upload Audio File
                </button>
              </div>

              <div className="p-6">
                {/* MODULE 1: RECORD VOICE */}
                {activeTab === 'record' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                        Recorder Status
                      </span>
                      <span
                        className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
                          isRecording
                            ? 'bg-red-500/10 text-red-400 border border-red-500/30 animate-pulse'
                            : audioBlob
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}
                      >
                        <span
                          className={`w-2 h-2 rounded-full ${
                            isRecording ? 'bg-red-500' : audioBlob ? 'bg-emerald-400' : 'bg-slate-500'
                          }`}
                        />
                        {isRecording ? 'Recording...' : audioBlob ? 'Audio Recorded' : 'Idle'}
                      </span>
                    </div>

                    <div className="h-44 rounded-xl border border-slate-800 bg-[#0B0F19] flex flex-col items-center justify-center p-4 relative overflow-hidden">
                      {isRecording ? (
                        <div className="flex flex-col items-center space-y-4">
                          <div className="flex items-center gap-1.5 h-12">
                            {[16, 28, 42, 20, 36, 48, 24, 40, 18, 32, 46, 22].map((height, i) => (
                              <div
                                key={i}
                                className="w-1.5 bg-gradient-to-t from-red-500 to-red-400 rounded-full wave-bar"
                                style={{
                                  animationDelay: `${(i % 5) * 0.15}s`,
                                  height: `${height}px`,
                                }}
                              />
                            ))}
                          </div>
                          <div className="text-center">
                            <span className="font-mono text-2xl font-bold text-red-400 tracking-wider">
                              {formatTime(recordingDuration)}
                            </span>
                            <p className="text-xs text-slate-400 mt-0.5">Capturing audio stream...</p>
                          </div>
                        </div>
                      ) : audioBlob ? (
                        <div className="flex flex-col items-center space-y-3">
                          <div className="p-3 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                            <CheckCircle2 className="w-8 h-8" />
                          </div>
                          <div className="text-center">
                            <p className="text-sm font-semibold text-slate-200">Sample Ready For Inspection</p>
                            <p className="text-xs font-mono text-slate-400 mt-0.5">
                              Duration: {formatTime(recordingDuration)} | Ready for Analysis
                            </p>
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center space-y-2 text-slate-500">
                          <Mic className="w-10 h-10 text-slate-600 stroke-[1.5]" />
                          <p className="text-sm font-medium">Click "Start Recording" to capture speech</p>
                          <p className="text-xs text-slate-600">High-fidelity acoustic capture</p>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-3">
                      {!isRecording ? (
                        <button
                          type="button"
                          onClick={startRecording}
                          className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-red-600/20 transition-all active:scale-[0.98]"
                        >
                          <Mic className="w-4 h-4" />
                          {audioBlob ? 'Record New Take' : 'Start Recording'}
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={stopRecording}
                          className="flex-1 py-3 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-red-600/30 transition-all animate-pulse active:scale-[0.98]"
                        >
                          <Square className="w-4 h-4 fill-current" />
                          Stop Recording
                        </button>
                      )}

                      {audioUrl && !isRecording && (
                        <>
                          <button
                            type="button"
                            onClick={() => togglePlayAudio(audioUrl)}
                            className="py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-sm flex items-center justify-center gap-2 border border-slate-700 transition-all"
                          >
                            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                            <span>{isPlaying ? 'Pause' : 'Preview'}</span>
                          </button>
                          <button
                            type="button"
                            onClick={clearRecording}
                            className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 border border-slate-700"
                          >
                            <RotateCcw className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                )}

                {/* MODULE 2: FILE UPLOAD */}
                {activeTab === 'upload' && (
                  <div className="space-y-6">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".wav,.mp3,.ogg,.m4a,.webm,.flac,audio/*"
                      onChange={(e) => {
                        if (e.target.files && e.target.files.length > 0) {
                          handleFileChange(e.target.files[0]);
                        }
                      }}
                      className="hidden"
                    />

                    <div
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      onClick={() => fileInputRef.current && fileInputRef.current.click()}
                      className={`h-44 rounded-xl border-2 border-dashed flex flex-col items-center justify-center p-6 text-center cursor-pointer transition-all ${
                        isDragging
                          ? 'border-blue-500 bg-blue-500/10'
                          : uploadedFile
                          ? 'border-emerald-500/50 bg-emerald-950/10'
                          : 'border-slate-800 bg-[#0B0F19] hover:border-slate-700'
                      }`}
                    >
                      {uploadedFile ? (
                        <div className="space-y-2">
                          <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                            <FileAudio className="w-6 h-6" />
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-200 truncate max-w-xs mx-auto">
                              {uploadedFile.name}
                            </p>
                            <p className="text-xs text-slate-400 font-mono mt-0.5">
                              {(uploadedFile.size / (1024 * 1024)).toFixed(2)} MB • Ready
                            </p>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="w-12 h-12 mx-auto rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
                            <UploadCloud className="w-6 h-6" />
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-200">
                              Click to browse or drag & drop audio here
                            </p>
                            <p className="text-xs text-slate-500 mt-0.5">
                              Supports .WAV, .MP3, .OGG, .WEBM, .M4A
                            </p>
                          </div>
                        </div>
                      )}
                    </div>

                    {uploadedFile && (
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={() => togglePlayAudio(uploadPreviewUrl)}
                          className="flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-sm flex items-center justify-center gap-2 border border-slate-700"
                        >
                          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                          <span>{isPlaying ? 'Pause' : 'Listen'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={clearUpload}
                          className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 border border-slate-700"
                        >
                          <RotateCcw className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* MODULE 3: PROMINENT ANALYZE BUTTON */}
                <div className="mt-6 pt-6 border-t border-slate-800">
                  <button
                    type="button"
                    disabled={!hasAudioSource || isLoading || isRecording}
                    onClick={handleAnalyze}
                    className={`w-full py-4 px-6 rounded-xl font-bold text-base flex items-center justify-center gap-3 transition-all ${
                      !hasAudioSource || isRecording
                        ? 'bg-slate-800/80 text-slate-500 cursor-not-allowed border border-slate-800'
                        : isLoading
                        ? 'bg-blue-600/80 text-white cursor-wait'
                        : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white shadow-xl shadow-blue-600/25 active:scale-[0.99]'
                    }`}
                  >
                    {isLoading ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Extracting MFCCs & Spectral Biometrics...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5" />
                        <span>Analyze Voice Sample</span>
                      </>
                    )}
                  </button>
                  <p className="text-center text-xs text-slate-500 mt-2.5">
                    Analyzes Mel-Frequency Cepstrum, spectral variance, and vocal tract anomalies
                  </p>
                </div>

              </div>
            </div>
          </div>

          {/* RIGHT: MODULE 4 (LIVE RESULTS DASHBOARD) */}
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-[#111827] border border-slate-800 rounded-2xl shadow-xl p-6 flex flex-col justify-between min-h-[480px]">
              <div>
                <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                  <div className="flex items-center gap-2.5">
                    <Activity className="w-5 h-5 text-blue-400" />
                    <h2 className="text-base font-bold text-slate-100">Live Detection Results</h2>
                  </div>
                  {analysisResult && (
                    <span className="text-xs font-mono text-slate-400">
                      Processed in {analysisResult.audio_duration_seconds}s audio
                    </span>
                  )}
                </div>

                {!analysisResult && !isLoading && (
                  <div className="h-80 flex flex-col items-center justify-center text-center p-6 text-slate-500 space-y-3">
                    <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-800">
                      <Shield className="w-10 h-10 text-slate-600" />
                    </div>
                    <p className="text-sm font-semibold text-slate-300">Awaiting Audio Submission</p>
                    <p className="text-xs text-slate-500 max-w-sm">
                      Record speech via your microphone or upload an audio file, then click "Analyze Voice Sample" to inspect authenticity.
                    </p>
                  </div>
                )}

                {isLoading && (
                  <div className="h-80 flex flex-col items-center justify-center space-y-4">
                    <div className="relative">
                      <div className="w-16 h-16 rounded-full border-4 border-slate-800 border-t-blue-500 animate-spin" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Activity className="w-6 h-6 text-blue-400 animate-pulse" />
                      </div>
                    </div>
                    <div className="text-center space-y-1">
                      <p className="text-sm font-bold text-slate-200">Executing Deep Acoustic Decomposition</p>
                      <p className="text-xs text-slate-400 font-mono">
                        Calculating 20-band MFCC delta matrices & pitch jitter...
                      </p>
                    </div>
                  </div>
                )}

                {analysisResult && !isLoading && (
                  <div className="space-y-6">
                    
                    {/* RISK LEVEL BADGE */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl bg-[#0B0F19] border border-slate-800">
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                          Classification Status
                        </p>
                        <h4 className="text-lg font-extrabold text-slate-100 mt-0.5">
                          {analysisResult.status}
                        </h4>
                      </div>

                      <div className="flex items-center gap-2">
                        <span
                          className={`px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest flex items-center gap-1.5 shadow-md ${
                            analysisResult.risk_level === 'HIGH'
                              ? 'bg-red-500/20 text-red-400 border border-red-500/50'
                              : analysisResult.risk_level === 'MEDIUM'
                              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/50'
                              : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50'
                          }`}
                        >
                          {analysisResult.risk_level === 'HIGH' ? (
                            <ShieldAlert className="w-4 h-4 text-red-400" />
                          ) : analysisResult.risk_level === 'MEDIUM' ? (
                            <AlertTriangle className="w-4 h-4 text-amber-400" />
                          ) : (
                            <ShieldCheck className="w-4 h-4 text-emerald-400" />
                          )}
                          {analysisResult.risk_level} RISK
                        </span>
                      </div>
                    </div>

                    {/* DUAL PROBABILITY PROGRESS BARS */}
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-xs font-bold mb-1.5">
                          <span className="text-red-400 flex items-center gap-1">
                            <Sparkles className="w-3.5 h-3.5" /> AI Synthetic / Cloned Probability
                          </span>
                          <span className="font-mono text-sm text-red-400 font-extrabold">
                            {analysisResult.ai_percentage}%
                          </span>
                        </div>
                        <div className="w-full h-3.5 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-800">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-red-600 via-rose-500 to-red-400 transition-all duration-1000 ease-out"
                            style={{ width: `${analysisResult.ai_percentage}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-xs font-bold mb-1.5">
                          <span className="text-emerald-400 flex items-center gap-1">
                            <ShieldCheck className="w-3.5 h-3.5" /> Authentic Human Probability
                          </span>
                          <span className="font-mono text-sm text-emerald-400 font-extrabold">
                            {analysisResult.human_percentage}%
                          </span>
                        </div>
                        <div className="w-full h-3.5 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-800">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-emerald-600 via-green-500 to-emerald-400 transition-all duration-1000 ease-out"
                            style={{ width: `${analysisResult.human_percentage}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800/80 text-xs text-slate-300 leading-relaxed">
                      {analysisResult.warning_message}
                    </div>

                    {/* TELEMETRY MATRIX */}
                    <div className="border-t border-slate-800/80 pt-4">
                      <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                        <Info className="w-3.5 h-3.5 text-blue-400" /> Biometric Feature Matrix
                      </p>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
                        <div className="bg-[#0B0F19] p-2.5 rounded-lg border border-slate-800">
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">MFCC Variance</p>
                          <p className="text-xs font-mono font-bold text-slate-200 mt-1">
                            {analysisResult.mfcc_variance_mean ?? 'N/A'}
                          </p>
                        </div>
                        <div className="bg-[#0B0F19] p-2.5 rounded-lg border border-slate-800">
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">Spectral Flatness</p>
                          <p className="text-xs font-mono font-bold text-slate-200 mt-1">
                            {analysisResult.spectral_flatness_mean ?? 'N/A'}
                          </p>
                        </div>
                        <div className="bg-[#0B0F19] p-2.5 rounded-lg border border-slate-800">
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">Pitch Jitter</p>
                          <p className="text-xs font-mono font-bold text-slate-200 mt-1">
                            {analysisResult.pitch_jitter_percent ? `${analysisResult.pitch_jitter_percent}%` : 'N/A'}
                          </p>
                        </div>
                        <div className="bg-[#0B0F19] p-2.5 rounded-lg border border-slate-800">
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">Spectral Contrast</p>
                          <p className="text-xs font-mono font-bold text-slate-200 mt-1">
                            {analysisResult.spectral_contrast_mean ? `${analysisResult.spectral_contrast_mean} dB` : 'N/A'}
                          </p>
                        </div>
                        <div className="bg-[#0B0F19] p-2.5 rounded-lg border border-slate-800">
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">Zero-Crossing</p>
                          <p className="text-xs font-mono font-bold text-slate-200 mt-1">
                            {analysisResult.zero_crossing_rate_mean ?? 'N/A'}
                          </p>
                        </div>
                        <div className="bg-[#0B0F19] p-2.5 rounded-lg border border-slate-800">
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">Spectral Rolloff</p>
                          <p className="text-xs font-mono font-bold text-slate-200 mt-1">
                            {analysisResult.spectral_rolloff_mean ? `${analysisResult.spectral_rolloff_mean} Hz` : 'N/A'}
                          </p>
                        </div>
                        <div className="bg-[#0B0F19] p-2.5 rounded-lg border border-slate-800">
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">Delta Dynamics</p>
                          <p className="text-xs font-mono font-bold text-slate-200 mt-1">
                            {analysisResult.delta_mfcc_variance ?? 'N/A'}
                          </p>
                        </div>
                        <div className="bg-[#0B0F19] p-2.5 rounded-lg border border-slate-800">
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">Harmonic Ratio</p>
                          <p className="text-xs font-mono font-bold text-slate-200 mt-1">
                            {analysisResult.harmonic_energy_ratio ? `${(analysisResult.harmonic_energy_ratio * 100).toFixed(1)}%` : 'N/A'}
                          </p>
                        </div>
                      </div>
                    </div>

                  </div>
                )}
              </div>

              <div className="border-t border-slate-800/80 pt-4 mt-6 flex items-center justify-between text-xs text-slate-500">
                <span>Voice Biometric Verification Layer</span>
                <span className="font-mono">Security Grade: High</span>
              </div>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}
